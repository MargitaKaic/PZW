
function provjeri() {

	var pitanje1 = document.kviz.pitanje1.value;
	var pitanje2 = document.kviz.pitanje2.value;
	var pitanje3 = document.kviz.pitanje3.value;

	var rezultat = 0;

	if ( pitanje1 == "hr" ) {
		rezultat++;
	}

	if ( pitanje2 == "true" ) {
		rezultat++;
	}

	if ( pitanje3 == "b" ) {
		rezultat++;
	}


	var messages = ["Ma ti si genije, čudo prirode!", "Vidio sam i bolje", "Nemam komentara"];
	var pictures = ["top.gif", "ok.gif", "fail.gif"];

	var range;

	if ( rezultat < 1 ) {
		range = 2;
	}

	if ( rezultat > 0 && rezultat < 3 ) {
		range = 1;
	}

	if ( rezultat > 2 ) {
		range = 0;
	}


	document.getElementById("after").style.visibility = "visible";

	document.getElementById("poruka").innerHTML = messages[range];

	document.getElementById("broj_tocnih").innerHTML = "Imaš " + rezultat + " točnih odgovora";

	document.getElementById("slika").src = pictures[range];
	
}